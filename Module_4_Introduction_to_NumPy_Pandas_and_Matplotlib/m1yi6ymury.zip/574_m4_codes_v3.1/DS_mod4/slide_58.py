import pandas

data = {'a':10, 'b':20, 'c':30}
series = pandas.Series(data)
print(series)