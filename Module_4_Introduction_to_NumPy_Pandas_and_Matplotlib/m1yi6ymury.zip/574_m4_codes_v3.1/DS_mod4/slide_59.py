import pandas

s = pandas.Series([10, 20, 30, 40, 50])

print(s[1:4])