import numpy as np
x=np.zeros(5)
print(x)
