import matplotlib.pyplot as plt, numpy

y = numpy.random.randn(100, 100)
plt.hist(y)
plt.show()