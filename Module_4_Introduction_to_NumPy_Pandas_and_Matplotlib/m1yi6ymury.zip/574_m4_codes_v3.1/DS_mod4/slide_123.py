import matplotlib.pyplot as plt
import numpy as np
y = np.arange(1, 3)
plt.plot(y, 'y')
plt.plot(y+5, 'm')
plt.plot(y+10, 'c')
plt.show()